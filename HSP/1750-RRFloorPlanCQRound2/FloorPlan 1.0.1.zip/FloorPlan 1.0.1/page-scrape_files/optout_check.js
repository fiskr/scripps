Krux.ns._default.kxjsonp_optOutCheck({
  status: 200,
  body: {  }
});