_satellite.pushAsyncScript(function(event, target, $variables){
  // Conditions
// Trigger rule at Bottom of Page
// Non-Sequential Javascript 
// hgtv.com: JArJSez7-

  window.Krux||((Krux=function(){Krux.q.push(arguments)}).q=[]);
  (function(){
    var k=document.createElement('script');k.type='text/javascript';k.async=true;
    var m,src=(m=location.href.match(/\bkxsrc=([^&]+)/))&&decodeURIComponent(m[1]);
    k.src = /^https?:\/\/([a-z0-9_\-\.]+\.)?krxd\.net(:\d{1,5})?\/+/i.test(src) ? src : src === "disable" ? "" :  (location.protocol==="https:"?"https:":"http:")+"//cdn.krxd.net/controltag?confid=JArJSez7";
    var s=document.getElementsByTagName('script')[0];s.parentNode.insertBefore(k,s);
  }());
});
